columns = df.columns[:12]
corr = df[columns].corr()
corr