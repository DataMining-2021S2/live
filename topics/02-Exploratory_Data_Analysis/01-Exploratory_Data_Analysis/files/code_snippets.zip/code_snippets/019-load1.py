df = pd.read_table('src/Analysis.txt')
print(df.shape)
df.head()