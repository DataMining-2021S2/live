df = pd.read_table('src/Analysis.txt', sep='\s+', header=None)
print(df.shape)
df.head()