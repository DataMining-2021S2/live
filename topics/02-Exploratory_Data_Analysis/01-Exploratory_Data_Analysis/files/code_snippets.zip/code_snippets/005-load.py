df = pd.read_csv("tips.csv")
print(df.shape)
df.head(10)