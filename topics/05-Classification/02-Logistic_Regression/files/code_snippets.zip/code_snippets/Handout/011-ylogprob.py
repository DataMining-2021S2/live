y_log_prob = model.predict_log_proba(X_test)
y_log_prob