from sklearn.metrics import accuracy_score
accuracy_score(y_test, y_pred)