from sklearn.naive_bayes import MultinomialNB
model = MultinomialNB()